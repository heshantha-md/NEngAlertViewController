//
//  ViewController.swift
//  NEngAlertViewController
//
//  Created by Nadeeshan Jayawardana on 6/23/18.
//  Copyright © 2018 NEngineering. All rights reserved.
//

import UIKit

class ViewController: UIViewController, NEngAlertViewControllerDelegate { // Add NEngAlertViewControllerDelegate to ViewController

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func defaultButtonTouchUpInsideAction(sender: UIButton) {
        
        // Default
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100001)
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        self.present(alertviewcontroller, animated: false, completion: nil)
    }
    
    @IBAction func redButtonTouchUpInsideAction(sender: UIButton) {
        
        // Red style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100002) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.logo(borderColor: .groupTableViewBackground)
        alertviewcontroller.background(color: UIColor(red:1.00, green:0.24, blue:0.47, alpha:1.0))
        alertviewcontroller.background(effect: .light)
        alertviewcontroller.title(color: .white)
        alertviewcontroller.message(color: .white)
        alertviewcontroller.message(font: UIFont (name: "HelveticaNeue-bold", size: 20)!)
        alertviewcontroller.doneButton(backgroundColor: .groupTableViewBackground)
        alertviewcontroller.doneButton(foregroundColor: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.doneButton(font: UIFont (name: "HelveticaNeue-bold", size: 20)!)
        alertviewcontroller.cancelButton(backgroundColor: .groupTableViewBackground)
        alertviewcontroller.cancelButton(foregroundColor: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.buttonSeparator(color: .lightGray)
        alertviewcontroller.buttonBorder(color: .lightGray)
        self.present(alertviewcontroller, animated: false, completion: nil)
    }
    
    @IBAction func purpleButtonTouchUpInsideAction(sender: UIButton) {
        
        // Purple style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100003) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.logo(borderColor: UIColor(red:0.89, green:0.76, blue:0.99, alpha:1.0))
        alertviewcontroller.background(effect: .dark)
        alertviewcontroller.title(color: UIColor(red:0.35, green:0.14, blue:0.79, alpha:1.0))
        alertviewcontroller.title(font: UIFont (name: "HelveticaNeue-bold", size: 24)!)
        alertviewcontroller.message(color: .darkGray)
        alertviewcontroller.doneButton(backgroundColor: UIColor(red:0.65, green:0.49, blue:1.00, alpha:1.0))
        alertviewcontroller.cancelButton(backgroundColor: UIColor(red:0.35, green:0.14, blue:0.79, alpha:1.0))
        alertviewcontroller.buttonSeparator(color: UIColor(red:0.35, green:0.14, blue:0.79, alpha:1.0))
        alertviewcontroller.buttonBorder(color: UIColor(red:0.35, green:0.14, blue:0.79, alpha:1.0))
        self.present(alertviewcontroller, animated: false, completion: nil)

    }
    
    @IBAction func orangeButtonTouchUpInsideAction(sender: UIButton) {
        
        // Orange style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100004) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.logo(borderColor: .orange)
        alertviewcontroller.background(color: .darkGray)
        alertviewcontroller.background(effect: .light)
        alertviewcontroller.title(color: .white)
        alertviewcontroller.message(color: .white)
        alertviewcontroller.doneButton(backgroundColor: .orange)
        alertviewcontroller.cancelButton(backgroundColor: .orange)
        alertviewcontroller.buttonSeparator(color: .orange)
        alertviewcontroller.buttonBorder(color: .gray)
        self.present(alertviewcontroller, animated: false, completion: nil)
    }
    
    @IBAction func darkButtonTouchUpInsideAction(sender: UIButton) {
        
        // Dark style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100005) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.logo(borderColor: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.background(color: .groupTableViewBackground)
        alertviewcontroller.background(effect: .light)
        alertviewcontroller.title(color: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.message(color: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.doneButton(backgroundColor: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.doneButton(font: UIFont (name: "HelveticaNeue-bold", size: 20)!)
        alertviewcontroller.cancelButton(backgroundColor: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.buttonSeparator(color: UIColor(red:0.33, green:0.31, blue:0.31, alpha:1.0))
        alertviewcontroller.buttonBorder(color: .gray)
        self.present(alertviewcontroller, animated: false, completion: nil)
    }
    
    @IBAction func blueButtonTouchUpInsideAction(sender: UIButton) {
        
        // Blue style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100006) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.logo(borderColor: UIColor(red:0.85, green:0.91, blue:0.97, alpha:1.0))
        alertviewcontroller.background(effect: .dark)
        alertviewcontroller.title(color: UIColor(red:0.24, green:0.59, blue:1.00, alpha:1.0))
        alertviewcontroller.title(font: UIFont (name: "HelveticaNeue", size: 32)!)
        alertviewcontroller.message(color: .darkGray)
        alertviewcontroller.doneButton(backgroundColor: UIColor(red:0.24, green:0.59, blue:1.00, alpha:1.0))
        alertviewcontroller.cancelButton(backgroundColor: UIColor(red:0.24, green:0.59, blue:1.00, alpha:1.0))
        alertviewcontroller.buttonSeparator(color: UIColor(red:0.24, green:0.59, blue:1.00, alpha:1.0))
        alertviewcontroller.buttonBorder(color: .lightGray)
        self.present(alertviewcontroller, animated: false, completion: nil)
    }
    
    @IBAction func greenButtonTouchUpInsideAction(sender: UIButton) {
        
        // Green style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100007) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(backgroundColor: UIColor(red:1.00, green:0.72, blue:0.00, alpha:1.0))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.background(color: .groupTableViewBackground)
        alertviewcontroller.background(effect: .light)
        alertviewcontroller.title(font: UIFont (name: "HelveticaNeue-light", size: 30)!)
        alertviewcontroller.title(color: .darkGray)
        alertviewcontroller.message(font: UIFont (name: "HelveticaNeue-bold", size: 18)!)
        alertviewcontroller.doneButton(backgroundColor: UIColor(red:0.01, green:0.76, blue:0.53, alpha:1.0))
        alertviewcontroller.cancelButton(backgroundColor: UIColor(red:0.01, green:0.76, blue:0.53, alpha:1.0))
        alertviewcontroller.buttonSeparator(color: UIColor(red:0.01, green:0.76, blue:0.53, alpha:1.0))
        self.present(alertviewcontroller, animated: false, completion: nil)

    }
    
    @IBAction func pinkButtonTouchUpInsideAction(sender: UIButton) {
        
        // Pink style
        let alertviewcontroller = NEngAlertViewController(title: "NEngAlertView", message: "This is an awesome alert view that you can customize as you want", cancelButtonTitle: "Cancel", doneButtonTitle: "Continue") // Implement NEngAlertViewController instance
        alertviewcontroller.delegate = self // Assign instance delegate to NEngAlertViewControllerDelegate
        alertviewcontroller.tag(id: 100008) // Assign a tag to NEngAlertViewController instance, So uniquely can identify the alert controller inside delegate methods
        alertviewcontroller.modalPresentationStyle = .overCurrentContext
        alertviewcontroller.logo(image: #imageLiteral(resourceName: "ic-logo"))
        alertviewcontroller.logo(contentMode: .center)
        alertviewcontroller.logo(borderColor: .white)
        alertviewcontroller.background(color: UIColor(red:0.98, green:0.16, blue:0.60, alpha:1.0))
        alertviewcontroller.background(effect: .dark)
        alertviewcontroller.title(color: UIColor(red:0.35, green:0.14, blue:0.79, alpha:1.0))
        alertviewcontroller.title(color: .groupTableViewBackground)
        alertviewcontroller.title(font: UIFont (name: "HelveticaNeue-bold", size: 36)!)
        alertviewcontroller.message(color: .white)
        alertviewcontroller.message(font: UIFont (name: "HelveticaNeue-bold", size: 18)!)
        alertviewcontroller.doneButton(backgroundColor: .white)
        alertviewcontroller.doneButton(foregroundColor: .darkGray)
        alertviewcontroller.doneButton(font: UIFont (name: "HelveticaNeue-bold", size: 20)!)
        alertviewcontroller.cancelButton(backgroundColor: .white)
        alertviewcontroller.cancelButton(foregroundColor: .darkGray)
        alertviewcontroller.buttonSeparator(color: .white)
        alertviewcontroller.buttonBorder(color: .lightGray)
        alertviewcontroller.backgroundTap(enable: false)
        self.present(alertviewcontroller, animated: false, completion: nil)

    }
    
    // MARK: Delegate functions
    
    func doneButtonDidTap(sender: UIButton, tag: NSInteger) {
        print("\(tag) Done button did tap")
    }
    
    func cancelButtonDidTap(sender: UIButton, tag: NSInteger) {
        print("\(tag) Cancel button did tap")
    }
}

